/* Tabler Icons by Pawel Kuna, MIT. Source: github.com/tabler/tabler-icons */
'use strict';
const GTCursorPresets=(()=>{
const data={"pointer":["M7.904 17.563a1.2 1.2 0 0 0 2.228 .308l2.09 -3.093l4.907 4.907a1.067 1.067 0 0 0 1.509 0l1.047 -1.047a1.067 1.067 0 0 0 0 -1.509l-4.907 -4.907l3.113 -2.09a1.2 1.2 0 0 0 -.309 -2.228l-13.582 -3.904l3.904 13.563"],"heart":["M19.5 12.572l-7.5 7.428l-7.5 -7.428a5 5 0 1 1 7.5 -6.566a5 5 0 1 1 7.5 6.572"],"rocket":["M4 13a8 8 0 0 1 7 7a6 6 0 0 0 3 -5a9 9 0 0 0 6 -8a3 3 0 0 0 -3 -3a9 9 0 0 0 -8 6a6 6 0 0 0 -5 3","M7 14a6 6 0 0 0 -3 6a6 6 0 0 0 6 -3","M14 9a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"],"target":["M11 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0","M7 12a5 5 0 1 0 10 0a5 5 0 1 0 -10 0","M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0"],"star":["M12 17.75l-6.172 3.245l1.179 -6.873l-5 -4.867l6.9 -1l3.086 -6.253l3.086 6.253l6.9 1l-5 4.867l1.179 6.873l-6.158 -3.245"],"bolt":["M13 3l0 7l6 0l-8 11l0 -7l-6 0l8 -11"]};
const list=Object.keys(data).map(name=>({id:'tabler-'+name,label:name[0].toUpperCase()+name.slice(1)}));
const has=id=>Object.prototype.hasOwnProperty.call(data,String(id).replace(/^tabler-/,''))&&String(id).startsWith('tabler-');
const url=id=>{const name=String(id).replace(/^tabler-/,'');if(!has(id))return '';const svg='<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="white" stroke="#111111" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+data[name].map(path=>'<path d="'+path+'"/>').join('')+'</svg>';return 'data:image/svg+xml,'+encodeURIComponent(svg);};
return {list,has,url};
})();
