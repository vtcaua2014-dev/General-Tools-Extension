(() => {
'use strict';
if(globalThis.__generalToolsContent)return;globalThis.__generalToolsContent=true;
const topFrame=window===window.top;
let settings={},root,shadow,style,frameCount=0,lastFrame=0,fps=0,rafId=0;
let stopwatch=GTStopwatchEngine.defaults(),positions={};
let media=null,mediaObserver,mediaQueued=false;
const now=()=>performance.now();
function stop(e){e.stopPropagation();}
function mount(){
 if(root?.isConnected)return;
 root=document.createElement('div');root.id='general-tools-overlay';
 root.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:2147483647;';
 shadow=root.attachShadow({mode:'open'});
 const css=document.createElement('style');css.textContent=`
 :host{all:initial}*{box-sizing:border-box}
 .box{position:fixed;pointer-events:auto;background:#121212;color:#fff;border:1px solid #555;border-radius:12px;font:12px system-ui,Arial,sans-serif;padding:12px;box-shadow:0 12px 40px #0008;max-width:95vw;user-select:none}
 .handle{cursor:move;touch-action:none;font-size:9px;color:#aaa;letter-spacing:1.4px;margin-bottom:9px;user-select:none}
 .clock{min-width:185px;max-width:95vw;--clock-color:#fff;--clock-size:34px}
 .clock-time{font:700 var(--clock-size) / 1.15 ui-monospace,Consolas,monospace;color:var(--clock-color);white-space:nowrap;font-variant-numeric:tabular-nums;letter-spacing:-1.5px}
 .clock[data-font='system'] .clock-time{font-family:system-ui,'Segoe UI',sans-serif}
 .clock[data-font='serif'] .clock-time{font-family:Georgia,serif}
 .clock[data-font='rounded'] .clock-time{font-family:'Trebuchet MS',system-ui,sans-serif}
 .clock-meta{font-size:10px;letter-spacing:.1em;opacity:.75;display:flex;justify-content:space-between;gap:12px;margin-bottom:6px}
 .clock-status{border-radius:30px;background:#3c3c3c;padding:3px 7px;font-size:9px;white-space:nowrap}
 .clock-actions{display:flex;flex-wrap:wrap;gap:5px;margin-top:10px}
 button{font:600 10px system-ui,Arial;background:#333;color:white;border:1px solid #777;border-radius:6px;padding:6px 9px;cursor:pointer}
 button:hover{background:#444}
 .clock-laps{font:11px ui-monospace,Consolas,monospace;max-height:112px;overflow:auto;margin-top:10px;border-top:1px solid #ffffff22;padding-top:7px}
 .clock-laps .clock-lap{display:flex;justify-content:space-between;gap:8px;padding:3px 0;color:#bbb}
 .clock-lap span:last-child{color:#fff}
 .clock[data-mode='livesplit']{background:#050505;border-radius:4px}.clock[data-mode='livesplit'] .clock-time{text-align:right;color:#29cc54}
 .clock[data-mode='chrono']{background:transparent;border:0;box-shadow:none;padding:5px}.clock[data-mode='chrono'] .clock-time{background:#0b0b0bec;border-radius:12px;padding:8px 12px;letter-spacing:2px}
 .clock[data-mode='chrono'] .clock-meta,.clock[data-mode='chrono'] .clock-actions,.clock[data-mode='chrono'] .clock-laps{background:#121212eb;border-radius:9px;padding:6px}
 .clock[data-mode='floating']{border-radius:22px;padding:15px;background:#101316e8}.clock[data-mode='floating'] .clock-time{text-align:center}
 .clock[data-mode='floating'] .clock-meta:before{content:'◉';color:#8de3f2}
 .clock[data-mode='lite']{padding:8px 10px;border-radius:8px}.clock[data-mode='lite'] .clock-meta{display:flex}.clock[data-mode='lite'] .clock-laps{display:block}.clock[data-mode='lite'] .clock-time{font-size:calc(var(--clock-size) * .75)}
 .keys-area{display:flex;flex-wrap:wrap;gap:14px;align-items:flex-start}
 .key-cluster{display:grid;grid-template-columns:repeat(3,var(--k-size,40px));grid-template-rows:repeat(2,var(--k-size,40px));gap:4px}
 .key{height:var(--k-size,40px);min-width:var(--k-size,40px);padding:6px 3px;display:grid;place-items:center;border:1px solid #767676;border-radius:7px;background:#262626;text-align:center;font:700 12px system-ui,Arial;color:white;transition:background .055s,transform .055s,border-color .055s}
 .key.on{background:var(--active,#fff);border-color:#fff;color:#000;transform:translateY(2px) scale(.96)}
 .key.space{width:100%;grid-column:1/4;margin-top:2px}
 .key-extras{display:flex;gap:4px;flex-wrap:wrap;max-width:240px;margin-top:8px}
 .key-extras .key{padding-inline:10px}
 .keys-legend{font:9px system-ui,sans-serif;color:#999;letter-spacing:1.5px;margin:7px 0 4px}
 .fps-value{font:800 14px ui-monospace,monospace}

.box{padding:5px 7px;border:1px solid #ffffff28;border-radius:6px;background:rgba(10,11,13,.75)!important;box-shadow:0 3px 14px #0005;opacity:.86;backdrop-filter:blur(5px)}
.box:hover,.box:focus-within{opacity:1}.handle{position:absolute;top:-5px;right:-5px;width:14px;height:14px;margin:0;background:#171717;border:1px solid #ffffff35;border-radius:50%;font-size:0;color:transparent!important;opacity:0}
.box:hover .handle,.handle:focus-visible{opacity:.8}
.clock{min-width:0!important;max-width:210px!important;width:auto!important}.clock-meta,.clock-laps{display:none!important}
.clock[data-mode='lite']{padding:5px 7px!important}.clock[data-mode='lite'] .clock-time{font-size:clamp(16px,calc(var(--clock-size)*.85),28px)!important}
.clock-actions{display:flex;gap:3px;margin:2px 0 0;max-height:0;opacity:0;overflow:hidden;transition:max-height .14s,opacity .14s}
.clock:hover .clock-actions,.clock:focus-within .clock-actions{max-height:32px;opacity:1}
.clock-actions button{font-size:9px;padding:3px 6px;background:#242424;border-radius:3px}
.key-cluster{grid-template-columns:repeat(3,25px);grid-template-rows:repeat(2,25px);gap:2px}.key{height:25px;min-width:25px;padding:1px 2px;font:750 9px system-ui;background:#ffffff0b;border-radius:4px}
.keys-area{gap:6px}.key-extras{gap:2px;margin:0;max-width:164px}.key-extras .key{padding-inline:5px}
.keys-legend{display:none!important}#keys{padding:4px 5px}#fps{padding:3px 6px;border-radius:5px}.fps-value{font:700 11px ui-monospace,monospace}
@media(prefers-reduced-motion:reduce){.clock-actions{transition:none}}

 `;
 shadow.append(css);
 (document.fullscreenElement||document.documentElement).append(root);
}
function panel(id,label,x,y){
 const b=document.createElement('div');b.id=id;b.className='box';
 const p=positions[id]||{x,y};b.style.left=Math.max(0,Math.min(Number(p.x)||0,innerWidth-100))+'px';b.style.top=Math.max(0,Math.min(Number(p.y)||0,innerHeight-70))+'px';
 /* Neutral compact overlay. */
 const h=document.createElement('div');h.className='handle';h.textContent=label+' · DRAG';b.append(h);
 let drag;
 h.onpointerdown=e=>{drag={x:e.clientX,y:e.clientY,left:parseFloat(b.style.left),top:parseFloat(b.style.top)};h.setPointerCapture(e.pointerId);e.preventDefault();e.stopPropagation();};
 h.onpointermove=e=>{if(!drag)return;b.style.left=Math.max(0,Math.min(innerWidth-b.offsetWidth,drag.left+e.clientX-drag.x))+'px';b.style.top=Math.max(0,Math.min(innerHeight-b.offsetHeight,drag.top+e.clientY-drag.y))+'px';};
 h.onpointerup=()=>{if(!drag)return;drag=null;positions[id]={x:parseFloat(b.style.left),y:parseFloat(b.style.top)};chrome.storage.local.set({overlayPositions:positions});};
 ['click','keydown','keyup'].forEach(e=>b.addEventListener(e,stop));shadow.append(b);return b;
}
function clockButton(box,label,action){const b=document.createElement('button');b.textContent=label;b.addEventListener('click',()=>timerAction(action));box.append(b);}
async function timerAction(action){
 if(!topFrame)return;
 try{const reply=await chrome.runtime.sendMessage({type:'gtStopwatch',action});
  if(reply?.ok){stopwatch=GTStopwatchEngine.normalize(reply.stopwatch);updateTimer();}
 }catch(e){console.warn('General Tools timer:',e.message);}
}
function updateTimer(){
 if(!shadow)return;
 const box=shadow.getElementById('timer'),d=shadow.getElementById('digits');if(!box||!d)return;
 const s=stopwatch, ms=GTStopwatchEngine.elapsedMs(s);
 box.dataset.mode=s.mode;box.dataset.font=s.font;box.style.setProperty('--clock-color',s.color);box.style.setProperty('--clock-size',s.size+'px');
 box.style.width=Math.max(108,Math.min(210,Math.round(s.size*5.7)))+'px';
 /* Compact background controlled by CSS. */
 const displayFormat=s.format==='auto'?(s.mode==='floating'?'tenths':s.mode==='chrono'?'hms':'auto'):s.format;
 const val=GTStopwatchEngine.formatTime(ms,displayFormat);
 if(d.textContent!==val)d.textContent=val;
 const label=shadow.getElementById('clockMode');if(label)label.textContent=({livesplit:'LiveSplit',chrono:'Chrono',floating:'Floating Clock',lite:'Lite'})[s.mode];
 const status=shadow.getElementById('clockStatus');if(status)status.textContent=s.phase==='running'?'RUNNING':s.phase==='paused'?'PAUSED':'READY';
 const btn=shadow.getElementById('clockToggle');if(btn)btn.textContent=GTStopwatchEngine.buttonLabel(s);
 const laps=shadow.getElementById('laps');if(laps){
  laps.hidden=!s.showLaps;
  const rev=s.laps.slice(-6).map((v,i)=>({name:GTStopwatchEngine.splitNames(s)[s.laps.length-Math.min(6,s.laps.length)+i]||'Split '+(s.laps.length-Math.min(6,s.laps.length)+i+1),value:v})).reverse();
  const signature=rev.map(x=>x.name+':'+x.value).join('|')+';'+s.pb;
  if(laps.dataset.signature!==signature){laps.dataset.signature=signature;laps.replaceChildren();
   if(s.pb){const pb=document.createElement('div');pb.className='clock-lap';pb.textContent='PB '+GTStopwatchEngine.formatTime(s.pb,'ms');laps.append(pb);}
   rev.forEach(x=>{const line=document.createElement('div');line.className='clock-lap';
    const name=document.createElement('span'),tm=document.createElement('span');name.textContent=x.name;tm.textContent=GTStopwatchEngine.formatTime(x.value,'ms');line.append(name,tm);laps.append(line);});
  }
 }
}
function makeKey(code,label,gridColumn,gridRow){const e=document.createElement('div');e.className='key';e.dataset.code=code;e.textContent=label;
 if(gridColumn)e.style.gridColumn=String(gridColumn);if(gridRow)e.style.gridRow=String(gridRow);return e;}
function keyName(code){return code.replace(/^Key|^Digit/,'').replace('Arrow','').replace('Space','SPACE').replace('Control','CTRL').replace('Shift','SHIFT');}
function drawKeys(box){
 const raw=String(settings.keyCodes||'KeyW,KeyA,KeyS,KeyD,Space').split(',').map(s=>s.trim()).filter(Boolean).slice(0,24);
 const codes=new Set(raw),area=document.createElement('div');area.className='keys-area';area.style.setProperty('--active',/^#[0-9a-f]{6}$/i.test(settings.activeColor)?settings.activeColor:'#fff');
 const groups=[{ids:['KeyW','KeyA','KeyS','KeyD'],name:'WASD'},{ids:['ArrowUp','ArrowLeft','ArrowDown','ArrowRight'],name:'ARROWS'}];
 const used=new Set();
 groups.forEach(group=>{
  if(!group.ids.some(id=>codes.has(id)))return;
  const section=document.createElement('div'),title=document.createElement('div');title.className='keys-legend';title.textContent=group.name;
  const grid=document.createElement('div');grid.className='key-cluster';
  group.ids.forEach((id,i)=>{if(!codes.has(id))return;used.add(id);const slot=[[2,1],[1,2],[2,2],[3,2]][i];grid.append(makeKey(id,keyName(id),...slot));});
  section.append(title,grid);area.append(section);
 });
 if(codes.has('Space')){used.add('Space');const row=document.createElement('div');row.style.width='100%';row.style.marginTop='5px';row.append(makeKey('Space','SPACE'));row.firstElementChild.style.width='100%';area.append(row);}
 const extras=raw.filter(id=>!used.has(id));if(extras.length){const list=document.createElement('div');list.className='key-extras';extras.forEach(id=>list.append(makeKey(id,keyName(id))));area.append(list);}
 box.append(area);
}
function draw(){
 if(!topFrame)return;mount();shadow.querySelectorAll('.box').forEach(e=>e.remove());
 if(settings.timer){
  const b=panel('timer','MOVE',12,12);b.classList.add('clock');
  const meta=document.createElement('div');meta.className='clock-meta';
  const name=document.createElement('span');name.id='clockMode';const status=document.createElement('span');status.id='clockStatus';status.className='clock-status';meta.append(name,status);
  const d=document.createElement('div');d.id='digits';d.className='clock-time';
  const buttons=document.createElement('div');buttons.className='clock-actions';
  const start=document.createElement('button');start.id='clockToggle';start.onclick=()=>timerAction('press');buttons.append(start);
  clockButton(buttons,'Split (E)','lap');
  const list=document.createElement('div');list.id='laps';list.className='clock-laps';
  b.append(d,buttons,list);updateTimer();
 }
 if(settings.keys){const b=panel('keys','MOVE',12,105);drawKeys(b);}
 if(settings.fps){const b=panel('fps','MOVE',12,72);const f=document.createElement('div');f.className='fps-value';f.id='fpsValue';f.textContent='… FPS';b.append(f);}
 cancelAnimationFrame(rafId);frameCount=0;lastFrame=now();if(settings.timer||settings.fps)rafId=requestAnimationFrame(tick);
}
function tick(t){frameCount++;if(t-lastFrame>=1000){fps=Math.round(frameCount*1000/(t-lastFrame));frameCount=0;lastFrame=t;const f=shadow?.getElementById('fpsValue');if(f)f.textContent=fps+' FPS';}updateTimer();if(settings.timer||settings.fps)rafId=requestAnimationFrame(tick);}
function key(code,down){shadow?.querySelectorAll('.key').forEach(e=>{if(e.dataset.code===code)e.classList.toggle('on',down);});}
const editable=e=>e.composedPath().some(n=>n instanceof HTMLElement&&(n.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(n.tagName)));
let mouse={x:innerWidth/2,y:innerHeight/2};document.addEventListener('pointermove',e=>{mouse={x:e.clientX,y:e.clientY};},{passive:true});
function triple(){const el=document.elementFromPoint(mouse.x,mouse.y);if(!el||el===root)return;for(const delay of [0,80,160])setTimeout(()=>{for(const type of ['mousedown','mouseup','click'])el.dispatchEvent(new MouseEvent(type,{view:window,bubbles:true,cancelable:true,clientX:mouse.x,clientY:mouse.y,button:0,buttons:type==='mousedown'?1:0}));},delay);}
function onKey(e,down){if(editable(e))return;
 if(settings.keys){if(topFrame)key(e.code,down);else window.top.postMessage({generalToolsOverlay:true,type:'key',code:e.code,down},'*');}
 if(!down||e.repeat||e.ctrlKey||e.metaKey||e.altKey||e.shiftKey)return;
 if(settings.triple&&e.code==='F6'){triple();return;}
 if(settings.timer){const action={KeyP:'press',KeyQ:'press',KeyE:'lap',F8:'press',F9:'reset',F10:'lap'}[e.code];if(action){e.preventDefault();if(topFrame)timerAction(action);else window.top.postMessage({generalToolsOverlay:true,type:'timer',action},'*');}}
}
document.addEventListener('keydown',e=>onKey(e,true),true);document.addEventListener('keyup',e=>onKey(e,false),true);
window.addEventListener('blur',()=>{if(topFrame)shadow?.querySelectorAll('.on').forEach(e=>e.classList.remove('on'));else window.top.postMessage({generalToolsOverlay:true,type:'clear'},'*');});
window.addEventListener('message',e=>{if(!topFrame||e.source===window||!e.data?.generalToolsOverlay)return;const m=e.data;
 if(m.type==='key'&&settings.keys&&typeof m.code==='string')key(m.code,!!m.down);
 if(m.type==='clear')shadow?.querySelectorAll('.on').forEach(e=>e.classList.remove('on'));
 if(m.type==='timer'&&settings.timer&&['press','toggle','reset','lap'].includes(m.action))timerAction(m.action);
});
function applyCursor(){if(!style){style=document.createElement('style');style.id='general-tools-cursor';document.documentElement.append(style);}let cursor=['crosshair','cell','pointer'].includes(settings.cursor)?settings.cursor:'';if(GTCursorPresets.has(settings.cursor))cursor=`url("${GTCursorPresets.url(settings.cursor)}") 2 2, auto`;if(settings.cursor==='custom'&&/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(settings.cursorData||''))cursor=`url("${settings.cursorData}") 0 0, auto`;style.textContent=cursor?`html,body,body *{cursor:${cursor}!important}`:'';}
function applyMedia(){if(!media)return;document.querySelectorAll('audio,video').forEach(e=>{if(Math.abs(e.playbackRate-media.rate)>.001)e.playbackRate=media.rate;if(Math.abs(e.volume-media.volume)>.001)e.volume=media.volume;});}
function scheduleMedia(){if(mediaQueued)return;mediaQueued=true;setTimeout(()=>{mediaQueued=false;applyMedia();},80);}
function setMedia(rate,volume){media={rate:Math.max(.25,Math.min(4,Number(rate)||1)),volume:Math.max(0,Math.min(1,Number(volume)||0))};applyMedia();if(!mediaObserver){mediaObserver=new MutationObserver(records=>{if(records.some(r=>[...r.addedNodes].some(n=>n.nodeType===1&&(n.matches('video,audio')||n.querySelector('video,audio')))))scheduleMedia();});mediaObserver.observe(document.documentElement,{childList:true,subtree:true});document.addEventListener('play',scheduleMedia,true);document.addEventListener('loadedmetadata',scheduleMedia,true);}}
function apply(s){settings=s||{};applyCursor();draw();}
chrome.runtime.onMessage.addListener((m,s,respond)=>{if(m.type!=='gt')return;try{switch(m.action){case 'settings':apply(m.settings);break;case 'media':setMedia(m.rate,m.volume);break;case 'resetPositions':positions={};chrome.storage.local.set({overlayPositions:{}});draw();break;
 case 'timerToggle':if(topFrame)timerAction('toggle');break;
 case 'timerReset':if(topFrame)timerAction('reset');break;
 case 'timerLap':if(topFrame)timerAction('lap');break;}
 respond({ok:true});}catch(e){respond({ok:false,error:e.message});}});
chrome.storage.onChanged.addListener((changes,area)=>{if(area!=='local')return;
 if(changes.settings)apply(changes.settings.newValue);
 if(changes[GTStopwatchEngine.KEY]){stopwatch=GTStopwatchEngine.normalize(changes[GTStopwatchEngine.KEY].newValue);updateTimer();}
});
document.addEventListener('fullscreenchange',()=>{if(root)(document.fullscreenElement||document.documentElement).append(root);});
chrome.storage.local.get(['settings','overlayPositions',GTStopwatchEngine.KEY]).then(d=>{positions=d.overlayPositions||{};stopwatch=GTStopwatchEngine.normalize(d[GTStopwatchEngine.KEY]);apply(d.settings||{});});
})();
