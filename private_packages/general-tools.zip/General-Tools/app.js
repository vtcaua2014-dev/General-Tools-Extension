'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const pages={home:'Overview',gaming:'Gaming & overlays',media:'Speed & media',tabs:'Tabs & sessions',cursor:'Cursors',privacy:'Ad blocking',scripts:'User scripts',utilities:'Notes & utilities',games:'Games & speedrun',about:'About'};
let toastTimeout,targetTab,cursorData='';
function notify(t){$('#status').textContent=t;$('#status').style.display='block';clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>$('#status').style.display='none',6500);}
const guard=fn=>async(...args)=>{try{await fn(...args);}catch(e){notify(e.message||String(e));}};
function btn(text,fn){const b=document.createElement('button');b.textContent=text;b.onclick=guard(fn);return b;}
function go(id){$$('.view').forEach(e=>e.hidden=e.id!==id);$$('nav button').forEach(e=>e.classList.toggle('active',e.dataset.id===id));$('#title').textContent=pages[id];if(id==='tabs')renderTabs();if(id==='scripts')renderScripts();}
for(const [id,name]of Object.entries(pages)){const b=btn(name,()=>go(id));b.dataset.id=id;$('#nav').append(b);}
for(const id of ['gaming','tabs','cursor','utilities'])$('#shortcuts').append(btn(pages[id]+' →',()=>go(id)));
$$('[data-go]').forEach(b=>b.onclick=()=>go(b.dataset.go));
if(new URLSearchParams(location.search).has('full'))document.body.classList.add('full');
$('#expand').onclick=()=>chrome.tabs.create({url:chrome.runtime.getURL('index.html?full=1')+(targetTab?.id?'&tab='+targetTab.id:'')});
async function current(){
 if(!targetTab){const [t]=await chrome.tabs.query({active:true,currentWindow:true});targetTab=t;}
 if(!targetTab?.id||!/^https?:/.test(targetTab.url||''))throw Error('Open an HTTP/HTTPS website and use the extension there. Internal Chrome pages are protected.');return targetTab;
}
async function page(action,data={}){const t=await current();try{return await chrome.tabs.sendMessage(t.id,{type:'gt',action,...data},{frameId:0});}catch{throw Error('Reload the page after installing the extension and try again.');}}
async function allFrames(action,data={}){const t=await current();try{await chrome.tabs.sendMessage(t.id,{type:'gt',action,...data});}catch{throw Error('Reload the website and try again.');}}
async function settings(){const {settings={}}=await chrome.storage.local.get('settings');return settings;}
function readGaming(){const s={};$$('[data-setting]').forEach(e=>s[e.dataset.setting]=e.type==='checkbox'?e.checked:e.value);return s;}
$('#applyGaming').onclick=guard(async()=>{const s={...await settings(),...readGaming()};await chrome.storage.local.set({settings:s});await allFrames('settings',{settings:s});notify('Overlays applied. These preferences will also be used on future websites.');});
$$('[data-page]').forEach(b=>b.onclick=guard(async()=>{if(b.dataset.page==='screenshot'){const t=await current();await chrome.tabs.update(t.id,{active:true});const url=await chrome.tabs.captureVisibleTab(t.windowId,{format:'png'});download(url,'General-Tools-capture.png');notify('Capture created.');}else await page(b.dataset.page);}));
function number(id,min,max){const n=Number($(id).value);if(!Number.isFinite(n)||n<min||n>max)throw Error(`Use a number between ${min} and ${max}.`);return n;}
$('#applyMedia').onclick=guard(async()=>{await allFrames('media',{rate:number('#mediaSpeed',.25,4),volume:number('#volume',0,100)/100});notify('Media settings applied to accessible frames.');});
$('#resetMedia').onclick=guard(async()=>{await allFrames('media',{rate:1,volume:1});$('#mediaSpeed').value=1;$('#volume').value=100;notify('Speed and volume reset to 1× and 100%.');});
// This function is serialized by chrome.scripting and executes entirely in the page MAIN world.
function setGameSpeed(speed){
 if(!window.__generalToolsClock){
 const perf=performance.now.bind(performance),date=Date.now.bind(Date),st=window.setTimeout.bind(window),si=window.setInterval.bind(window),raf=window.requestAnimationFrame.bind(window);
 const c={speed:1,p:perf(),vp:perf(),d:date(),vd:date()};
 c.now=()=>c.vp+(perf()-c.p)*c.speed;c.date=()=>c.vd+(date()-c.d)*c.speed;
 c.set=v=>{const p=c.now(),d=c.date();c.p=perf();c.d=date();c.vp=p;c.vd=d;c.speed=v;};
 try{Object.defineProperty(performance,'now',{configurable:true,value:()=>c.now()});Date.now=()=>c.date();}catch{}
 window.setTimeout=function(fn,delay,...args){return st(fn,Number(delay)/c.speed,...args);};
 window.setInterval=function(fn,delay,...args){return si(fn,Number(delay)/c.speed,...args);};
 window.requestAnimationFrame=fn=>raf(()=>fn(c.now()));window.__generalToolsClock=c;
 }window.__generalToolsClock.set(speed);
}
async function speed(v){const t=await current();await chrome.scripting.executeScript({target:{tabId:t.id,allFrames:true},world:'MAIN',func:setGameSpeed,args:[v]});notify(v+'× applied. Reload the game if it uses clocks cached before the adjustment.');}
$('#applySpeed').onclick=guard(()=>speed(number('#gameSpeed',.25,4)));
$('#resetSpeed').onclick=guard(async()=>{await speed(1);$('#gameSpeed').value=1;});
$('#recorder').onclick=()=>chrome.tabs.create({url:chrome.runtime.getURL('recorder.html')});
function download(url,name){const a=document.createElement('a');a.href=url;a.download=name;a.click();}
function jsonDownload(value,name){const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'}));download(url,name);setTimeout(()=>URL.revokeObjectURL(url),10000);}
async function renderTabs(){
 const {sessions=[]}=await chrome.storage.local.get('sessions');$('#sessions').replaceChildren();
 for(const s of sessions){const row=document.createElement('div');row.className='row';const title=document.createElement('strong');title.textContent=s.name+' · '+s.tabs.length+' tabs';row.append(title,btn('Restore',async()=>{for(const t of s.tabs){if(/^https?:\/\//.test(t.url))await chrome.tabs.create({url:t.url,active:false});}notify('Session restored.');}),btn('Delete',async()=>{await chrome.storage.local.set({sessions:sessions.filter(x=>x.id!==s.id)});renderTabs();}));$('#sessions').append(row);}
 const tabs=await chrome.tabs.query({currentWindow:true});const q=$('#tabSearch').value.toLowerCase();$('#tabList').replaceChildren();
 for(const t of tabs.filter(t=>(t.title+' '+t.url).toLowerCase().includes(q))){const row=document.createElement('div');row.className='row';const title=document.createElement('strong');title.textContent=t.title||'Untitled';const sub=document.createElement('small');sub.textContent=t.url;row.append(title,sub,btn('Open',()=>chrome.tabs.update(t.id,{active:true})),btn(t.mutedInfo?.muted?'Unmute':'Mute',async()=>{await chrome.tabs.update(t.id,{muted:!t.mutedInfo?.muted});renderTabs();}));$('#tabList').append(row);}
}
$('#tabSearch').oninput=guard(renderTabs);
$('#saveTabs').onclick=guard(async()=>{const tabs=(await chrome.tabs.query({currentWindow:true})).filter(t=>/^https?:\/\//.test(t.url||'')).map(t=>({title:t.title,url:t.url}));if(!tabs.length)throw Error('No HTTP/HTTPS tabs in this window.');const {sessions=[]}=await chrome.storage.local.get('sessions');sessions.unshift({id:crypto.randomUUID(),name:$('#sessionName').value.trim()||new Date().toLocaleString('en-US'),tabs});await chrome.storage.local.set({sessions});await renderTabs();notify('Session saved. Your tabs remain open.');});
$('#cursorFile').onchange=guard(async e=>{const f=e.target.files[0];if(!f)return;if(f.type!=='image/png'||f.size>5e6)throw Error('Choose a PNG up to 5 MB.');const bitmap=await createImageBitmap(f),c=document.createElement('canvas'),scale=Math.min(1,64/bitmap.width,64/bitmap.height);c.width=Math.round(bitmap.width*scale);c.height=Math.round(bitmap.height*scale);c.getContext('2d').drawImage(bitmap,0,0,c.width,c.height);cursorData=c.toDataURL();bitmap.close();$('#cursorType').value='custom';$('#cursorPreview').src=cursorData;$('#cursorPreview').hidden=false;});
async function cursor(type){if(type==='custom'&&!cursorData)throw Error('Choose an image first.');const s={...await settings(),cursor:type,cursorData:type==='custom'?cursorData:''};await chrome.storage.local.set({settings:s});await allFrames('settings',{settings:s});notify('Cursor updated.');}
$('#applyCursor').onclick=guard(()=>cursor($('#cursorType').value));$('#removeCursor').onclick=guard(()=>cursor('default'));
$('#adblock').onchange=guard(async e=>{const v=e.target.checked;const r=await chrome.runtime.sendMessage({type:'adblock',enabled:v});if(!r.ok){e.target.checked=!v;throw Error(r.error);}notify(v?'Ad blocking enabled. Reload already open pages.':'Ad blocking disabled.');});
function clearScript(){for(const id of ['scriptId','scriptName','scriptMatches','scriptCode'])$('#'+id).value='';}
$('#clearScript').onclick=clearScript;
async function sync(){const r=await chrome.runtime.sendMessage({type:'syncScripts'});if(!r.ok)throw Error(r.error);}
async function renderScripts(){const {scripts=[]}=await chrome.storage.local.get('scripts');$('#scriptList').replaceChildren();for(const s of scripts){const row=document.createElement('div');row.className='row';const title=document.createElement('strong');title.textContent=s.name+' · '+(s.enabled?'enabled':'paused');row.append(title,btn('Edit',()=>{$('#scriptId').value=s.id;$('#scriptName').value=s.name;$('#scriptMatches').value=s.matches.join('\n');$('#scriptCode').value=s.code;}),btn(s.enabled?'Pause':'Enable',async()=>{s.enabled=!s.enabled;await chrome.storage.local.set({scripts});await renderScripts();await sync();notify('Script updated. Reload the website.');}),btn('Delete',async()=>{await chrome.storage.local.set({scripts:scripts.filter(x=>x.id!==s.id)});await renderScripts();await sync();}));$('#scriptList').append(row);}}
$('#saveScript').onclick=guard(async()=>{const name=$('#scriptName').value.trim(),code=$('#scriptCode').value,matches=$('#scriptMatches').value.split('\n').map(s=>s.trim()).filter(Boolean);if(!name||!code.trim()||!matches.length)throw Error('Fill in the name, sites, and code.');if(matches.some(m=>!/^https?:\/\/[^/]+\/.*$/.test(m)&&!/^\*:\/\/[^/]+\/.*$/.test(m)))throw Error('Use patterns such as https://example.com/* or *://*.example.com/*');const {scripts=[]}=await chrome.storage.local.get('scripts');const id=$('#scriptId').value||'gt-'+crypto.randomUUID();const s={id,name,code,matches,enabled:true};const i=scripts.findIndex(s=>s.id===id);if(i<0)scripts.push(s);else scripts[i]=s;await chrome.storage.local.set({scripts});await renderScripts();await sync();clearScript();notify('Script saved and registered. Reload the website to run it.');});
$('#syncScripts').onclick=guard(async()=>{await sync();notify('Manager available. Scripts synchronized.');});
$('#scriptFile').onchange=guard(async e=>{const f=e.target.files[0];if(!f)return;if(f.size>1e6)throw Error('Script is larger than 1 MB.');const code=await f.text();$('#scriptCode').value=code;$('#scriptName').value=(code.match(/\/\/\s*@name\s+(.+)/)||[])[1]||f.name;$('#scriptMatches').value=[...code.matchAll(/\/\/\s*@match\s+(.+)/g)].map(m=>m[1].trim()).join('\n');$('#scriptId').value='';notify('Imported for editing. Check the sites and click Save and enable.');});
let noteTimer;
$('#notes').oninput=()=>{$('#notesState').textContent='Saving…';clearTimeout(noteTimer);noteTimer=setTimeout(guard(async()=>{await chrome.storage.local.set({notes:$('#notes').value});$('#notesState').textContent='Saved in this browser';}),250);};
function count(){const t=$('#textTool').value;$('#textCount').textContent=`${t.length} characters · ${t.trim()?t.trim().split(/\s+/).length:0} words`;}
$('#textTool').oninput=count;
$$('[data-text]').forEach(b=>b.onclick=guard(async()=>{const e=$('#textTool'),s=e.value;switch(b.dataset.text){case 'upper':e.value=s.toUpperCase();break;case 'lower':e.value=s.toLowerCase();break;case 'trim':e.value=s.trim().replace(/[ \t]+/g,' ');break;case 'json':e.value=JSON.stringify(JSON.parse(s),null,2);break;case 'encode':e.value=encodeURIComponent(s);break;case 'decode':e.value=decodeURIComponent(s);break;case 'copy':await navigator.clipboard.writeText(s);notify('Copied.');}count();}));
$('#export').onclick=guard(async()=>{await chrome.storage.local.set({notes:$('#notes').value});jsonDownload({generalTools:1,data:await chrome.storage.local.get(null)},'General-Tools-backup.json');});
$('#import').onchange=guard(async e=>{const f=e.target.files[0];if(!f)return;if(f.size>8e6)throw Error('Backup is larger than 8 MB.');const x=JSON.parse(await f.text());if(x.generalTools!==1||!x.data||typeof x.data!=='object')throw Error('Invalid backup.');const data={};if(typeof x.data.notes==='string')data.notes=x.data.notes;if(Array.isArray(x.data.sessions))data.sessions=x.data.sessions.filter(s=>typeof s.name==='string'&&Array.isArray(s.tabs)).map(s=>({...s,id:crypto.randomUUID(),tabs:s.tabs.filter(t=>typeof t.url==='string'&&/^https?:\/\//.test(t.url))}));if(Array.isArray(x.data.scripts))data.scripts=x.data.scripts.filter(s=>typeof s.name==='string'&&typeof s.code==='string'&&Array.isArray(s.matches)).map(s=>({...s,id:'gt-'+crypto.randomUUID(),enabled:false}));await chrome.storage.local.set(data);await sync().catch(()=>{});await init();notify('Notes, sessions, and scripts imported. Scripts remain paused; page preferences are not imported.');});
$('#speedrun').onclick=()=>chrome.tabs.create({url:'https://www.speedrun.com/search?q='+encodeURIComponent($('#speedrunQuery').value.trim())});$('#surfvt').onclick=()=>chrome.tabs.create({url:'https://surfvt14.vercel.app'});
let reactionState='idle',reactionTime,reactionTimer;
$('#reaction').onclick=()=>{const b=$('#reaction');if(reactionState==='idle'){reactionState='waiting';b.textContent='Wait…';$('#reactionResult').textContent='Wait for the signal.';reactionTimer=setTimeout(()=>{reactionState='ready';reactionTime=performance.now();b.textContent='NOW!';b.classList.add('ready');},1500+Math.random()*3000);}else if(reactionState==='waiting'){clearTimeout(reactionTimer);reactionState='idle';b.textContent='Try again';$('#reactionResult').textContent='You clicked before the signal!';}else{$('#reactionResult').textContent=Math.round(performance.now()-reactionTime)+' ms';reactionState='idle';b.classList.remove('ready');b.textContent='Play again';}};
async function init(){const targetId=Number(new URLSearchParams(location.search).get('tab'));if(targetId){try{targetTab=await chrome.tabs.get(targetId);$('#site').textContent=new URL(targetTab.url).hostname;}catch{targetTab=null;}}const d=await chrome.storage.local.get(null),s=d.settings||{};$$('[data-setting]').forEach(e=>{if(s[e.dataset.setting]!==undefined){if(e.type==='checkbox')e.checked=s[e.dataset.setting];else e.value=s[e.dataset.setting];}});$('#notes').value=d.notes||'';$('#adblock').checked=!!d.adblock;$('#cursorType').value=s.cursor||'default';cursorData=s.cursorData||'';if(cursorData){$('#cursorPreview').src=cursorData;$('#cursorPreview').hidden=false;}const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(tab&&!tab.url?.startsWith(chrome.runtime.getURL(''))){targetTab=tab;try{$('#site').textContent=new URL(tab.url).hostname;}catch{}}}
go('home');guard(init)();
