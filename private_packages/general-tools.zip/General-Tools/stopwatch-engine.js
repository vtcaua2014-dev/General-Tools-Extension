/* General Tools Unified Stopwatch 1.1 — one clock, four visual layouts.
   Original logic adapted from the project owner's stopwatch specification.
   Inspired by the timing, split and visual concepts in the supplied P14 Functions package.
   Time measurement uses epoch milliseconds so runs survive MV3 service-worker shutdowns. */
'use strict';
const GTStopwatchEngine = (() => {
  const KEY = 'gtStopwatchV2';
  const MODES = ['livesplit', 'chrono', 'floating', 'lite'];
  const FORMATS = ['auto', 'hms', 'ms', 'tenths'];
  const FONTS = ['system', 'mono', 'serif', 'rounded'];
  const defaults = () => ({
    mode: 'lite', format: 'auto', phase: 'idle', readyLabel: false, running: false, elapsed: 0, startedAt: 0,
    laps: [], pb: 0, bestSegments: [], pbSplits: [], persist: true,
    color: '#ffffff', panelColor: '#121212', size: 26, font: 'system',
    showLaps: true, splitNames: ''
  });
  const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
  function normalize(raw) {
    const d = defaults(), s = raw && typeof raw === 'object' ? raw : {};
    const out = { ...d };
    out.mode = 'lite'; // LiveSplit Lite is now the unified default
    out.format = FORMATS.includes(s.format) ? s.format : d.format;
    out.font = FONTS.includes(s.font) ? s.font : d.font;
    out.phase = ['idle','running','paused'].includes(s.phase) ? s.phase : (s.running ? 'running' : (s.elapsed > 0 ? 'paused' : 'idle'));
    out.readyLabel = !!s.readyLabel;
    out.running = out.phase === 'running';
    out.elapsed = clamp(Number(s.elapsed) || 0, 0, 1e13);
    out.startedAt = clamp(Number(s.startedAt) || 0, 0, 1e14);
    out.laps = Array.isArray(s.laps) ? s.laps.slice(0, 250).map(n => clamp(Number(n)||0,0,1e13)) : [];
    out.pb = clamp(Number(s.pb)||0,0,1e13);
    out.history=Array.isArray(s.history)?s.history.slice(0,30).filter(x=>x&&typeof x.total==='number'):[];
    out.bestSegments = Array.isArray(s.bestSegments) ? s.bestSegments.slice(0,250).map(n => clamp(Number(n)||0,0,1e13)) : [];
    out.pbSplits = Array.isArray(s.pbSplits) ? s.pbSplits.slice(0,250).map(n => clamp(Number(n)||0,0,1e13)) : [];
    out.persist = s.persist !== false;
    out.color = /^#[0-9a-fA-F]{6}$/.test(s.color||'') ? s.color : d.color;
    out.panelColor = /^#[0-9a-fA-F]{6}$/.test(s.panelColor||'') ? s.panelColor : d.panelColor;
    out.size = clamp(Math.round(Number(s.size)||d.size),20,68);
    out.showLaps = s.showLaps !== false;
    out.splitNames = typeof s.splitNames === 'string' ? s.splitNames.slice(0,4000) : '';
    if (out.running && !out.startedAt) { out.running=false;out.phase='idle'; }
    return out;
  }
  function elapsedMs(s, current = Date.now()) {
    const st = normalize(s);
    return st.elapsed + (st.running ? Math.max(0,current - st.startedAt) : 0);
  }
  const pad = n => String(n).padStart(2,'0');
  function formatTime(ms, format='auto') {
    const n=Math.max(0,Math.floor(Number(ms)||0)), cs=Math.floor(n/10)%100;
    const total=Math.floor(n/1000), sec=total%60,min=Math.floor(total/60)%60,hrs=Math.floor(total/3600);
    if(format==='ms') return `${pad(Math.floor(total/60))}:${pad(sec)}.${pad(cs)}`;
    if(format==='tenths') return `${pad(hrs)}:${pad(min)}:${pad(sec)}.${Math.floor(cs/10)}`;
    if(format==='hms') return `${pad(hrs)}:${pad(min)}:${pad(sec)}.${pad(cs)}`;
    return hrs ? `${hrs}:${pad(min)}:${pad(sec)}.${pad(cs)}` : Math.floor(total/60) ? `${Math.floor(total/60)}:${pad(sec)}.${pad(cs)}` : `${sec}.${pad(cs)}`;
  }
  function apply(st, action, data={}, current=Date.now()) {
    const s=normalize(st), t=elapsedMs(s,current);
    switch(action){
      case 'press':
      case 'toggle': // compatibility with older shortcut bindings
        if(s.phase==='idle') { s.phase='running';s.elapsed=0;s.startedAt=current;s.running=true;s.laps=[];s.readyLabel=false; }
        else if(s.phase==='running') {
          s.elapsed=t;s.startedAt=0;s.running=false;s.phase='paused';
          if(t>0){ const isPb=!s.pb||t<s.pb;
            if(isPb){s.pb=t;s.pbSplits=s.laps.slice();}
            s.history=[{total:t,pb:isPb,splits:s.laps.slice()},...(s.history||[])].slice(0,30);
          }
        }
        else { s.phase='idle';s.elapsed=0;s.startedAt=0;s.running=false;s.laps=[];s.readyLabel=true; }
        break;
      case 'reset': {
        if(t>0 && (!s.pb || t<s.pb)) {s.pb=t;s.pbSplits=s.laps.slice();}
        let prev=0;
        s.laps.forEach((v,i)=>{const segment=v-prev;prev=v;if(segment>0 && (!s.bestSegments[i] || segment<s.bestSegments[i]))s.bestSegments[i]=segment;});
        s.running=false;s.phase='idle';s.readyLabel=true;s.elapsed=0;s.startedAt=0;s.laps=[];
        break;
      }
      case 'lap':
        if(s.phase==='running'&&s.laps.length<250)s.laps.push(t);
        break;
      case 'clearLaps':s.laps=[];break;
      case 'clearRecords':s.pb=0;s.pbSplits=[];s.bestSegments=[];break;
      case 'config': {
        const d=data&&typeof data==='object'?data:{};
        for(const k of ['format','font','persist','color','panelColor','size','showLaps','splitNames']) {
          if(Object.prototype.hasOwnProperty.call(d,k))s[k]=d[k];
        }
        return normalize(s);
      }
      case 'get':return s;
      default:throw Error('Unknown stopwatch action.');
    }
    return s;
  }
  const buttonLabel = s => (s.phase==='running'?'Running':s.phase==='paused'?'Paused':s.readyLabel?'Restart':'Start');
  const splitNames = s => (s.splitNames||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  return {KEY, defaults, normalize, elapsedMs, formatTime, apply, splitNames, buttonLabel};
})();
