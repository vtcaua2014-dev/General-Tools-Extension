(() => {
'use strict';
const $ = id => document.getElementById(id), E=GTStopwatchEngine;
let state=E.defaults(),busy=false;
const labels={livesplit:'LiveSplit',chrono:'Chrono',floating:'Floating Clock',lite:'Lite'};
function current(){return E.elapsedMs(state);}
function render(){
 const ms=current(),f=state.format==='auto'?(state.mode==='chrono'?'hms':state.mode==='floating'?'tenths':'auto'):state.format;
 $('display').textContent=E.formatTime(ms,f);$('status').textContent=state.phase==='running'?'RUNNING':state.phase==='paused'?'PAUSED':'READY';
 $('start').textContent=E.buttonLabel(state);
 $('modeLabel').textContent='LiveSplit Lite';$('preview').dataset.mode=state.mode;
 $('display').style.color=state.color;$('display').style.fontFamily=({mono:'ui-monospace,Consolas,monospace',system:'system-ui,sans-serif',rounded:'Trebuchet MS,system-ui,sans-serif',serif:'Georgia,serif'})[state.font];
 $('display').style.fontSize=state.size+'px';
 if(state.mode==='chrono')$('preview').style.background='#202020';else if(state.mode==='livesplit')$('preview').style.background='#000';else $('preview').style.background=state.panelColor;
 $('pb').textContent='PERSONAL BEST '+(state.pb?E.formatTime(state.pb,'ms'):'—');
 document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===state.mode));
 const list=$('laps'), signature=state.laps.join(',')+':'+state.pb+':'+state.splitNames;
 if(list.dataset.signature!==signature){list.dataset.signature=signature;list.replaceChildren();
  if(!state.laps.length){const li=document.createElement('li');li.className='empty';li.textContent='No splits recorded.';list.append(li);}
  const names=E.splitNames(state);
  state.laps.forEach((val,i)=>{const li=document.createElement('li'),title=document.createElement('span'),time=document.createElement('span'),delta=document.createElement('small');
   const prev=i?state.laps[i-1]:0;title.textContent=names[i]||`Split ${i+1}`;time.textContent=E.formatTime(val,'ms');
   delta.textContent='Δ '+E.formatTime(val-prev,'ms')+(state.bestSegments[i]?' · Best '+E.formatTime(state.bestSegments[i],'ms'):'');
   li.append(title,time,delta);list.append(li);
  });
 }
}
async function request(action,data){if(busy&&action!=='get')return;busy=true;
 try{const response=await chrome.runtime.sendMessage({type:'gtStopwatch',action,data});if(!response?.ok)throw Error(response?.error||'Stopwatch unavailable');state=E.normalize(response.stopwatch);render();}
 catch(e){console.error(e);$('status').textContent='ERROR';}finally{busy=false;}
}
function fill(){for(const k of ['format','font','color','panelColor','size','persist','showLaps','splitNames']){const el=$(k);if(el.type==='checkbox')el.checked=!!state[k];else el.value=state[k];}$('sizeOut').textContent=state.size+'px';}
async function config(patch){await request('config',patch);fill();}
$('start').onclick=()=>request('press');$('reset').onclick=()=>request('reset');$('lap').onclick=()=>request('lap');$('clearLaps').onclick=()=>request('clearLaps');
$('export').onclick=()=>{const names=E.splitNames(state),data=[['Index','Split','Total ms','Segment ms'],...state.laps.map((v,i)=>[i+1,names[i]||`Split ${i+1}`,Math.floor(v),Math.floor(v-(state.laps[i-1]||0))])];
 const csv=data.map(row=>row.map(x=>'"'+String(x).replaceAll('"','""')+'"').join(',')).join('\r\n');
 const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='general-tools-splits.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);
};
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>config({mode:b.dataset.mode}));
for(const k of ['format','font','color','panelColor','size','persist','showLaps'])$(k).addEventListener('change',e=>config({[k]:e.target.type==='checkbox'?e.target.checked:e.target.value}));
let debounce; $('splitNames').addEventListener('input',e=>{const text=e.target.value;clearTimeout(debounce);debounce=setTimeout(()=>config({splitNames:text}),450);});
document.addEventListener('keydown',e=>{if(e.target.closest('input,select,textarea,button')||e.ctrlKey||e.metaKey||e.altKey)return;
 if(e.repeat)return; const action={Space:'press',KeyP:'press',KeyQ:'press',KeyE:'lap',KeyL:'lap',KeyR:'reset',F8:'press',F9:'reset',F10:'lap'}[e.code];if(action){e.preventDefault();request(action);}
});
chrome.storage.onChanged.addListener((change,area)=>{if(area==='local'&&change[E.KEY]){state=E.normalize(change[E.KEY].newValue);fill();render();}});
request('get').then(fill);setInterval(render,42);
})();
