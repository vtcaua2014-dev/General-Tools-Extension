importScripts('stopwatch-engine.js');
'use strict';
async function syncScripts() {
  const {scripts=[]}=await chrome.storage.local.get('scripts');
  try {
    const current=await chrome.userScripts.getScripts();
    const enabled=scripts.filter(s=>s.enabled);
    // Register a validated batch before removing obsolete IDs. Update existing atomically per API call.
    const existing=new Set(current.map(s=>s.id));
    const specs=enabled.map(s=>({id:s.id,matches:s.matches,js:[{code:s.code}],runAt:'document_idle',world:'USER_SCRIPT',allFrames:false}));
    const add=specs.filter(s=>!existing.has(s.id)),update=specs.filter(s=>existing.has(s.id));
    if(add.length)await chrome.userScripts.register(add);
    if(update.length)await chrome.userScripts.update(update);
    const ids=current.filter(s=>!enabled.some(e=>e.id===s.id)).map(s=>s.id);
    if(ids.length)await chrome.userScripts.unregister({ids});
    return {ok:true};
  } catch(e) {return {ok:false,error:'Enable “Allow user scripts” in the extension details. '+e.message};}
}
async function setup(){
 await chrome.contextMenus.removeAll();
 chrome.contextMenus.create({id:'general-tools',title:'Open General Tools',contexts:['all']});
 const {adblock=false}=await chrome.storage.local.get('adblock');
 await chrome.declarativeNetRequest.updateEnabledRulesets({enableRulesetIds:adblock?['ads']:[],disableRulesetIds:adblock?[]:['ads']});
 await syncScripts();
}
chrome.runtime.onInstalled.addListener(()=>setup().catch(console.error));
chrome.runtime.onStartup.addListener(()=>{
 setup().catch(console.error);
 chrome.storage.local.get(GTStopwatchEngine.KEY).then(async d=>{
   const s=GTStopwatchEngine.normalize(d[GTStopwatchEngine.KEY]);
   if(!s.persist){s.running=false;s.elapsed=0;s.startedAt=0;s.laps=[];
     await chrome.storage.local.set({[GTStopwatchEngine.KEY]:s});}
 }).catch(console.error);
});
// Serialize actions because popup, page overlay and floating window share one timer.
let stopwatchQueue=Promise.resolve();
async function stopwatchRequest(m){
 const data=await chrome.storage.local.get(GTStopwatchEngine.KEY);
 const previous=GTStopwatchEngine.normalize(data[GTStopwatchEngine.KEY]);
 if(m.action==='get')return {ok:true,stopwatch:previous};
 const updated=GTStopwatchEngine.apply(previous,m.action,m.data);
 await chrome.storage.local.set({[GTStopwatchEngine.KEY]:updated});
 return {ok:true,stopwatch:updated};
}

chrome.contextMenus.onClicked.addListener(()=>chrome.runtime.openOptionsPage());
chrome.commands.onCommand.addListener(()=>chrome.runtime.openOptionsPage());
chrome.runtime.onMessage.addListener((m,s,respond)=>{
 if(s.id!==chrome.runtime.id)return;
 if(m.type==='gtStopwatch'){
  stopwatchQueue=stopwatchQueue.catch(()=>{}).then(()=>stopwatchRequest(m));
  stopwatchQueue.then(respond).catch(e=>respond({ok:false,error:e.message}));
  return true;
 }
 if(m.type==='syncScripts'){syncScripts().then(respond);return true;}
 if(m.type==='adblock'){
 chrome.declarativeNetRequest.updateEnabledRulesets({enableRulesetIds:m.enabled?['ads']:[],disableRulesetIds:m.enabled?[]:['ads']}).then(()=>chrome.storage.local.set({adblock:!!m.enabled})).then(()=>respond({ok:true})).catch(e=>respond({ok:false,error:e.message}));return true;
 }
});
